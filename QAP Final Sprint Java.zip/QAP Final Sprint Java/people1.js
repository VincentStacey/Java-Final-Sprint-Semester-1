fetch('./people.json')
    .then(response => response.json())
    .then(data => {
    console.log(data)
    // Loop through an array in the JSON data
    data.forEach(person => {
        console.log(getFullName(person));
        console.log(getHeight(person));
        console.log(getSalary(person));
        console.log(getOccupation(person));
    });

    var outputDiv = document.getElementById('output');
    if (outputDiv) {
      
      data.forEach(person => {
        var paragraph = document.createElement('p');

        paragraph.textContent = `Hello, my name is ${getFullName(person)}, I am ${getHeight(person)}, my profession is being a  ${getOccupation(person)} and I make $${getSalary(person)} million dollars per year.`;

        outputDiv.appendChild(paragraph);
      });
    } else {
      console.error('Output div not found.');
    }
    })
  .catch(error => {
    console.error(error);
    })
    .catch(error => {
    console.error(error);
    });

    function getHeight(person) {
        return `${person.height}`;
    }
    

    function getFullName(person) {
        return `${person.fname} ${person.lname}`;
        
    }

    function getSalary(person) {
        return `${person.salary}`;
    }

    function getOccupation(person) {
        return `${person.occupation}`;
    }



     
      